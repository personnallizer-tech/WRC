WRC ESPORT — ADMINISTRATION COMPLÈTE

OUVRIR
- Décompresse l'archive.
- Ouvre index.html dans Chrome/Edge.

ADMIN
- Ctrl + Shift + A
- Mot de passe de démonstration : WRC2026

L'ADMIN PERMET DE MODIFIER
- nom de team et titre du site
- logo (import d'une image depuis le PC)
- couleurs principales
- textes et titres de l'accueil
- boutons et leurs liens
- statistiques
- section À propos
- cartes À propos (ajout/suppression)
- titre/description du roster
- joueurs et rôles (ajout/suppression)
- titre/description des matchs
- matchs (ajout/suppression)
- texte communauté
- lien Discord
- réseaux sociaux
- footer
- réinitialisation complète

Les changements sont enregistrés dans localStorage du navigateur.

IMPORTANT POUR UNE MISE EN LIGNE
Cette version est un éditeur local. Le mot de passe est dans le code et n'est pas une sécurité serveur.
Pour une vraie administration en ligne, il faut une authentification côté serveur, une base de données, des sessions sécurisées et un hébergement. Je peux préparer cette version ensuite.
